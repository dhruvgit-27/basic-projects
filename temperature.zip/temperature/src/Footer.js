import React from "react";

function Footer() {
  return (
    <footer className="footer">
      © 2025 Dhruv's Temperature Converter. All Rights Reserved.
    </footer>
  );
}

export default Footer;
