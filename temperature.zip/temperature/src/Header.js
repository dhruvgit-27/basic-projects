import React from "react";

function Header() {
  return (
    <header className="header">
      🌡️ Dhruv's Temperature Converter 🌡️
    </header>
  );
}

export default Header;
