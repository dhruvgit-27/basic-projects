const products = [
    { id: 1, name: "Laptop", price: 50000 },
    { id: 2, name: "Smartphone", price: 30000 },
    { id: 3, name: "Headphones", price: 5000 },
  ];
  
  export default products;
  